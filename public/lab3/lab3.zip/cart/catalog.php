<?php

return [
    1 => ['title' => 'Keyboard',  'price' => 49.99],
    2 => ['title' => 'Mouse',     'price' => 19.99],
    3 => ['title' => 'Headset',   'price' => 79.00],
    4 => ['title' => 'Webcam',    'price' => 59.00],
];

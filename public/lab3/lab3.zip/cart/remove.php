<?php
require_once __DIR__ . '/../lib/bootstrap.php';

$id = (int)arr_get($_GET, 'id', 0);
if ($id <= 0) redirect('view.php');

if (isset($_SESSION['cart'][$id])) {
    unset($_SESSION['cart'][$id]);
}
$_SESSION['flash'] = 'Товар видалено із кошика.';
redirect('view.php');

<?php
require_once __DIR__ . '/../lib/bootstrap.php';

$cart = $_SESSION['cart'] ?? [];
$prev = cookie_json_get('previous_purchases');

$catalog  = require __DIR__ . '/catalog.php';

function lineTitle(int $id, array $catalog): string
{
    return h($catalog[$id]['title'] ?? "id={$id}");
}
function linePrice(int $id, array $catalog): float
{
    return (float)($catalog[$id]['price'] ?? 0.0);
}
$total = 0.0;
?>
<!doctype html>
<html lang="uk">

<head>
    <meta charset="utf-8">
    <title>Кошик</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <div class="container">
        <div class="card">
            <h1>Кошик</h1>
            <?php if ($f = flash_get()): ?>
                <div class="flash error"><?= h($f) ?></div>
            <?php endif; ?>

            <?php if ($cart): ?>
                <table>
                    <tr>
                        <th>Товар</th>
                        <th>К-сть</th>
                        <th>Ціна</th>
                        <th>Сума</th>
                        <th></th>
                    </tr>
                    <?php foreach ($cart as $id => $qty):
                        $price = linePrice((int)$id, $catalog);
                        $sum = $price * (int)$qty;
                        $total += $sum;
                    ?>
                        <tr>
                            <td><?= lineTitle((int)$id, $catalog) ?></td>
                            <td><?= (int)$qty ?></td>
                            <td>$<?= number_format($price, 2) ?></td>
                            <td>$<?= number_format($sum, 2) ?></td>
                            <td><a class="btn outline" href="remove.php?id=<?= (int)$id ?>">видалити</a></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <th colspan="3" style="text-align:right;">Разом:</th>
                        <th colspan="2">$<?= number_format($total, 2) ?></th>
                    </tr>
                </table>
                <div class="actions">
                    <a class="btn" href="checkout.php">Оформити (зберегти як попередні покупки)</a>
                </div>
            <?php else: ?>
                <p>Кошик порожній.</p>
            <?php endif; ?>

            <h2 style="margin-top:1.5rem;">Попередні покупки (з cookie)</h2>
            <?php if ($prev): ?>
                <ul>
                    <?php foreach (array_unique(array_map('intval', $prev)) as $pid): ?>
                        <li><?= lineTitle($pid, $catalog) ?> <span class="muted">#<?= (int)$pid ?></span></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="muted">Немає попередніх покупок.</p>
            <?php endif; ?>

            <div class="actions">
                <a class="btn outline" href="products.php">← До каталогу</a>
                <a class="btn outline" href="../index.php">На головну</a>
            </div>
        </div>
    </div>
</body>

</html>
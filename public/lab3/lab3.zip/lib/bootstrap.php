<?php

require_once __DIR__ . '/helpers.php';

ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.use_only_cookies', '1');

session_start();

$now = time();
$timeout = 60 * 5;
$last = arr_get($_SESSION, 'last_activity');

if ($last && ($now - (int)$last) > $timeout) {
    session_unset();
    session_destroy();
    session_start();
    $_SESSION['flash'] = 'Сесія завершена через неактивність (5 хв).';
}

$_SESSION['last_activity'] = $now;

function flash_get(): ?string
{
    $msg = arr_get($_SESSION, 'flash');
    unset($_SESSION['flash']);
    return $msg;
}
